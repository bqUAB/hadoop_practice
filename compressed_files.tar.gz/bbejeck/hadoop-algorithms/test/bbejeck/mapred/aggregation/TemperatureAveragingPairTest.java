package bbejeck.mapred.aggregation;

import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.*;
import static org.hamcrest.CoreMatchers.*;

/**
 * User: Bill Bejeck
 * Date: 10/8/12
 * Time: 9:25 PM
 */
public class TemperatureAveragingPairTest {


    @Before
    public void setUp() throws Exception {

    }

    @Test
    public void testSet() throws Exception {

    }

    @Test
    public void testWrite() throws Exception {

    }

    @Test
    public void testReadFields() throws Exception {

    }

    @Test
    public void testCompareTo() throws Exception {

    }

    @Test
    public void testRead() throws Exception {

    }

    @Test
    public void testEquals() throws Exception {

    }

    @Test
    public void testHashCode() throws Exception {

    }

    @Test
    public void testToString() throws Exception {

    }

    @Test
    public void testGetTemp() throws Exception {

    }

    @Test
    public void testGetCount() throws Exception {

    }
}
